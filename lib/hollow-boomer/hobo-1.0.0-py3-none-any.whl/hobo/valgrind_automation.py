"""Automates Valgrind usage.

Holds functions necessary to run Valgrind on a daemon.

    Typical usage example:

    from hobo.valgrind_automation import execute_valgrind_on_daemon

    execute_valgrind_on_daemon(repo_path, DAEMON_NAME, UNIT_CONFIG_FILE)
"""

# Standard Imports
from time import sleep
from typing import Tuple
import os
# Third Party Imports
# Local Imports
# pylint: disable=import-error
from hobo.common_automation import execute_systemctl_cmd, _validate_parameters
from hobo.daemon_automation import start_daemon, stop_daemon
from hobo.disk_operations import validate_file
from hobo.makefile_automation import install_binary, uninstall_binary
from hobo.makefile_rule_collection import MakefileRuleCollection
from hobo.misc import find_needle_range
from hobo.valgrindlogparser import ValgrindLogParser
from hobo.validation import validate_string
# pylint: enable=import-error


# Developer Note: Regarding the Pylint disable... Let's not make this function more complicated
# than it needs to be.
# pylint: disable=too-many-function-args
def execute_valgrind_on_daemon(repo_path: str, daemon_name: str, unit_config_filename: str,
                               rule_collection: MakefileRuleCollection,
                               sleep_time: int = 1) -> None:
    """Clean, build, install, start, stop, uninstall, and test daemon_name service w/ valgrind.

    Details
        1.  Prepare the environment for installation
        2.  rule_collection.clean_rule.execute()    \
        3.  rule_collection.build_rule.execute()     } ---> Installation
        4.  rule_collection.install_rule.execute()  /
        5.  Edit the unit_config_filename's ExecStart entry
        6.  systemctl start daemon_name
        7.  sleep(sleep_time)
        8.  systemctl stop daemon_name
        9.  rule_collection.uninstall_rule.execute()
        10. Analyze the Valgrind log file

    This function modifies the ExecStart in the unit config file to add the necessary Valgrind
    command.  In short, this method was chosen in an attempt to "future-proof" this script.
    Here are the two main reasons listed with detail:
        1. To ensure future compatibility of manual_integration.py.
        Features may be added to the daemon that aren't accounted for.  Every time that
        happens, this functionality will break.  Utilizing the installer, this script makes
        the assumption that the installation of the daemon will provide for all the default
        needs (e.g, config.ini) of the daemon.  That way, this script doesn't have to be
        modified each time a new daemon-requires-something-external feature (e.g., watch
        directory must be created) is implemented.
        2.  Utilizing systemd's `systemctl stop` functionality was an easy way to "stop" the
        daemon gracefully.  The alternative would have been to send kill commands through
        subprocess to the daemon's PID while also verifying that the Valgrind gdb server was
        killed as well.  This solution was cleaner and easier.  It's also future-
        proof(?).

    Args:
        repo_path: The relative or absolute pathname to the repo.
        daemon_name: The name of the systemd service to check.
        unit_config_filename: The absolute filename of daemon_name's .service file (which is
            probably daemon_name + '.service')
        rule_collection: A MakefileRuleCollection object containing the necessary MakefileRule
            objects necessary to clean, build, install, and uninstall the daemon_name.
        sleep_time: Optional; The number of seconds to sleep between the start and stop.

    Raises:
        OSError: repo_path does not exist, repo_path is not a directory, or Valgrind can not
            be located.
        RuntimeError: Errors were found in the Valgrind log.
        TypeError: Invalid data type.
        ValueError: Empty parameter.
        Bubbles up exceptions from MakefileRuleCollection and ValgrindLogParser
    """
    # LOCAL VARIABLES
    valgrind_abs_path = '/usr/bin/valgrind'                  # which valgrind
    log_dir = os.path.join(repo_path, 'devops', 'logs')      # Store logs here
    rel_log_filename = 'valgrind-daemon-analysis.log'        # Valgrind log
    log_parser = None                                        # Log parser obj
    # Absolute filename for Valgrind's logged analysis of daemon_name
    abs_log_filename = os.path.join(log_dir, rel_log_filename)
    # Command string to replace for ExecStart in the service unit config file
    valgrind_cmd_str = f'{valgrind_abs_path} --leak-check=full ' + \
                       '--track-origins=yes --tool=memcheck --vgdb=yes ' + \
                       '--show-error-list=yes --show-leak-kinds=all ' + \
                       f'--trace-children=yes --log-file={abs_log_filename}'

    # INPUT VALIDATION
    _validate_valgrind_parameters(repo_path, daemon_name, unit_config_filename,
                                  rule_collection, sleep_time)
    # Verify Valgrind exists
    if not os.path.exists(valgrind_abs_path):
        raise OSError(f'Unable to locate {valgrind_abs_path}')
    if not os.path.isfile(valgrind_abs_path):
        raise OSError(f'{valgrind_abs_path} is not a file?!')

    # EXECUTE VALGRIND
    # Prepare the environment
    # NOTE: Installation will fail with the following if the daemon is
    # running at installation time:
    #   cannot create regular file '<unit_config_filename>': Text file busy
    stop_daemon(daemon_name, report_errors=False)  # Best effort

    # Install
    # Calls the Makefile rules to clean, build, and install the daemon
    install_binary(rule_collection.clean_rule, rule_collection.build_rule,
                   rule_collection.install_rule)

    # Edit the service unit configuration file
    _edit_daemon_execstart(unit_config_filename, valgrind_cmd_str)

    # Start the daemon
    start_daemon(daemon_name)

    # Sleep
    sleep(sleep_time)  # Substitute for *actual* work to do

    # Stop the daemon
    stop_daemon(daemon_name)

    # Uninstall
    uninstall_binary(rule_collection.uninstall_rule)  # Clean up

    # Analyze the Valgrind log file
    log_parser = ValgrindLogParser(abs_log_filename)
    log_parser.parse()
    if log_parser.check_for_errors():
        print(log_parser.get_report())
        raise RuntimeError(f'Valgrind found an error in {daemon_name}\n'
                           f'See "{abs_log_filename}" for details')
    print(f'Valgrind approves of {daemon_name}\n')
# pylint: enable=too-many-function-args


def _edit_daemon_execstart(unit_config_filename: str, prepend_cmd: str) -> None:
    """Changes the daemon execution in unit_config_filename.

    Replaces the string `ExecStart=` with `ExecStart=<prepend_cmd ` within unit_config_filename.
    This function does not validate unit_config_filename and makes a few assumptions about what
    we'll find in the *.service file referenced by unit_config_filename.  This makes the function's
    behavior a bit fragile.

    Args:
        unit_config_filename: The absolute filename of daemon_name's .service file.
        prepend_cmd: The string to use when changing unit_config_filename.

    Raises:
        OSError: unit_config_filename can not be found or unit_config_filename is not a file.
        RuntimeError: Any failures occur during run-time.
        TypeError: prepend_cmd is an invalid data type.
        ValueError prepend_cmd is empty.
    """
    # LOCAL VARIABLES
    needle = 'ExecStart='  # Find this substring in the unit config
    file_contents = ''     # Current contents of the unit config
    new_contents = ''      # Modified contents to save in the unit config
    old_execstart = ''     # Old value of ExecStart in the unit config
    new_execstart = ''     # New value for ExecStart to save

    # INPUT VALIDATION
    # unit_config_filename
    validate_file(unit_config_filename, 'unit_config_filename', must_exist=True)
    # prepend_cmd
    validate_string(prepend_cmd, 'prepend_cmd', can_be_empty=False)

    # FIND AND REPLACE
    # Read file contents
    with open(unit_config_filename, 'r') as in_file:
        file_contents = in_file.read()
    # Verify needle exists
    if needle not in file_contents:
        raise RuntimeError(f'Unable to find "{needle}" in '
                           f'{unit_config_filename}')
    # Get the full 'needle' newline delimited string
    old_execstart = find_needle_range(file_contents, needle, '\n')
    if not old_execstart:
        raise RuntimeError('Unable to find newline delimited needle in '
                           f'{unit_config_filename}')
    new_execstart = needle + prepend_cmd + ' ' + \
        old_execstart[old_execstart.find(needle) + len(needle):]
    # Replace ExecStart in original
    new_contents = file_contents.replace(old_execstart, new_execstart, 1)
    # Overwrite file contents
    with open(unit_config_filename, 'w') as out_file:
        out_file.write(new_contents)


def _execute_systemctl_cmd(daemon_name: str, command: str,
                           as_root: bool = True) -> Tuple[str, str]:
    """Executes `systemctl command daemon_name` and returns results.

    Calls execute_subprocess_cmd() under the hood and does not validate daemon_name. This function
    was written in an attempt to avoid duplicated code and lets the caller decide the criteria for
    success or failure in the execution of the given systemctl command.

    Args:
        daemon_name: The name of the systemd service to command.
        command: The systemctl command to issue.
        as_root: Optional; If True, executes the command with sudo.

    Returns:
        A tuple containing stdout and stderr from the systemctl command.

    Raises:
        TypeError: Invalid data type.
        ValueError: Empty parameter.
    """
    return execute_systemctl_cmd(daemon_name, command, as_root)


def _validate_valgrind_parameters(repo_path: str, daemon_name: str, unit_config_filename: str,
                                  rule_collection: MakefileRuleCollection,
                                  sleep_time: int) -> None:
    """Validates input on behalf of execute_valgrind_on_daemon().

    Validates the type and content of all arguments provided but does not verify the existence of
    unit_config_filename. This function calls MakefileRuleCollection.verify() and bubbles up
    exceptions from MakefileRuleCollection.

    Args:
        repo_path: The relative or absolute pathname to the repo.
        daemon_name: The name of the systemd service to check.
        unit_config_filename: The absolute filename of daemon_name's .service file.
        rule_collection: A MakefileRuleCollection object containing the necessary MakefileRule
            objects necessary to clean, build, install, and uninstall the daemon_name.
        sleep_time: A non-negative number of seconds to pass to time.sleep.

    Raises:
        FileNotFoundError: repo_path or unit_config_filename does not exist.
        OSError: repo_path is not a directory or unit_config_filename is not a file.
        TypeError: Invalid data type.
        ValueError: Empty parameter or sleep_time is negative.
    """
    # INPUT VALIDATION
    # repo_path
    # daemon_name
    # rule_collection
    # sleep_time
    _validate_parameters(repo_path=repo_path, daemon_name=daemon_name,
                         rule_collection=rule_collection, sleep_time=sleep_time)
    # unit_config_filename
    # The unit_config_filename likely does not exist at "validation time" because it doesn't
    # appear until "install time".
    validate_file(unit_config_filename, 'unit_config_filename', must_exist=False)
