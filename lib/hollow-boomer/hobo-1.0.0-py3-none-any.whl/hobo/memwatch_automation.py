"""Holds all the functions necessary to execute a Memwatch-build of a daemon.

Functionality includes analyzing the Memwatch log file after running the daemon.

    Typical usage example:

    from hobo.memwatch_automation import execute_memwatch_on_daemon, parse_memwatch_log

    execute_memwatch_on_daemon(repo_path, DAEMON_NAME)
    parse_memwatch_log(abs_log_filename)
"""

# Standard Imports
from time import sleep
from typing import List
import os
# Third Party Imports
# Local Imports
# pylint: disable=import-error
from hobo.common_automation import _validate_parameters
from hobo.daemon_automation import start_daemon, stop_daemon
from hobo.disk_operations import delete_file, validate_file
from hobo.makefile_automation import install_binary, uninstall_binary
from hobo.makefile_rule_collection import MakefileRuleCollection
# pylint: enable=import-error


def execute_memwatch_on_daemon(repo_path: str, daemon_name: str,
                               rule_collection: MakefileRuleCollection,
                               sleep_time: int = 1) -> None:
    """Clean, build, install, start, stop, uninstall, and test daemon_name service w/ memwatch.

    Details
        1. Prepare the environment
        2. rule_collection.clean_rule.execute()    \
        3. rule_collection.build_rule.execute()     } ---> Installation
        4. rule_collection.install_rule.execute()  /
        5. systemctl start daemon_name
        6. sleep(sleep_time)
        7. systemctl stop daemon_name
        8. rule_collection.uninstall_rule.execute()
        9. Analyze the Memwatch log file

    Removes any "lingering" log files during execution to avoid misleading results. This function
    will not delete the Memwatch log file if any error was detected and also attempts to delete the
    log file following non-error execution.

    Args:
        repo_path: The relative or absolute pathname to the reo.
        daemon_name: The name of the systemd service to check.
        rule_collection: MakefileRuleCollection object containing the necessary MakefileRule
            objects necessary to clean, build, install, and uninstall the daemon_name.
        sleep_time: Optional; The number of seconds to sleep between the start and stop.

    Raises:
        OSError: repo_path does not exist or repo_path is not a directory.
        RuntimeError: Errors were found in the Memwatch log.
        TypeError: Invalid data type.
        ValueError: Empty parameter.
        Bubbles up exceptions from MakefileRuleCollection
    """
    # LOCAL VARIABLES
    # Absolute filename for Memwatch's logged analysis of daemon_name
    abs_log_filename = os.path.join(os.sep, 'memwatch.log')
    # Errors were detected in the Memwatch log file
    found_errors = False
    # List of errors detected in the Memwatch log file
    error_list = []

    # INPUT VALIDATION
    _validate_parameters(repo_path, daemon_name, rule_collection, sleep_time)

    # EXECUTE THE MEMWATCH-BUILD
    # Prepare the environment
    # NOTE: Installation will fail with the following if the daemon is
    # running at installation time:
    #   cannot create regular file '/usr/local/sbin/<daemon_name>.bin': Text file busy
    stop_daemon(daemon_name, report_errors=False)  # Best effort

    # Install
    # Calls the Makefile rules to clean, build, and install the daemon
    install_binary(rule_collection.clean_rule, rule_collection.build_rule,
                   rule_collection.install_rule)

    # Clear old log
    delete_file(abs_log_filename, ignore_missing=True)

    # Start the daemon
    start_daemon(daemon_name)

    # Sleep
    sleep(sleep_time)  # Substitute for *actual* work to do

    # Stop the daemon
    stop_daemon(daemon_name)

    # Uninstall
    uninstall_binary(rule_collection.uninstall_rule)  # Clean up

    # Analyze the Memwatch log file
    error_list = parse_memwatch_log(abs_log_filename)
    if error_list:
        found_errors = True

    # Delete Memwatch log file
    if not found_errors:
        delete_file(abs_log_filename)

    # DONE
    if found_errors:
        print('Errors Detected:')
        for error in error_list:
            print(f'\t{error}')
        raise RuntimeError(f'Memwatch found an error in {daemon_name}\n'
                           f'See "{abs_log_filename}" for details')
    print(f'Memwatch approves of {daemon_name}\n')


def parse_memwatch_log(log_filename: str) -> List[str]:
    """Parse the Memwatch log file.

    Parse the Memwatch log file and return all errors found in a list.

    Args:
        log_filename: A relative or absolute name for the Memwatch log to parse.

    Returns:
        A list of errors found (which may be an empty list if no errors were found).

    Raises:
        TypeError: log_filename is not a string.
        ValueError: log_filename is empty.
        FileNotFoundError: log_filename is not found.
        OSError: log_filename is not a file.
    """
    # LOCAL VARIABLES
    list_of_errors = []  # Errors found in the Memwatch log file
    log_contents = ''    # Contents of the Memwatch log file
    # List of error strings to look for in the Memwatch log file
    # NOTE: These error strings may be referenced in memwatch.h but the
    #   *actual* strings were extracted from memwatch.c.
    error_strings = [
        'double-free:', 'underflow:', 'overflow:',
        'WILD free:', 'NULL free:', 'failed',
        'realloc:', 'limit fail:', 'assert trap:',
        'verify trap:', 'wild pointer:', 'unfreed:',
        'check:', 'relink:', 'internal:',
        'mark:'
    ]

    # INPUT VALIDATION
    validate_file(log_filename, 'log_filename', must_exist=True)

    # READ LOG FILE
    with open(log_filename, 'r') as in_file:
        log_contents = in_file.read()

    # SEARCH LOG CONTENTS
    for log_entry in log_contents.split('\n'):
        if log_entry:
            # print(f'LOG ENTRY: {log_entry}')  # DEBUGGING
            for error_string in error_strings:
                if error_string in log_entry:
                    list_of_errors.append(log_entry)

    # DONE
    return list_of_errors
