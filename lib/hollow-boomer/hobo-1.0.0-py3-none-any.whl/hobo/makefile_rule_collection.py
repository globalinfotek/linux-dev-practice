"""Defines the MakefileRuleCollection class.

Defines the MakefileRuleCollection class to help abstract passing MakefileRule objects as
parameters.  Also, assists in the validation of MakefileRule objects.

    Typical usage example:

    from hobo.makefile_rule_collection import MakefileRuleCollection

    clean_rule = MakefileRule(makefile_filename='Makefile', makefile_rule='clean')
    build_rule = MakefileRule(makefile_filename='Makefile', makefile_rule='build')
    rule_collection = MakefileRuleCollection(clean_rule=clean_rule. build_rule=build_rule)
    rule_collection.verify()  # Checks object type and calls verify() for all MakefileRule objs
"""

# Standard Imports
# Third Party Imports
# Local Imports
from hobo.makefile_rule import MakefileRule
from hobo.validation import validate_type


# NOTE: Disabling 'too-few-public-methods' because I don't *need* anymore public methods.
# Someone may argue that there are too *many* public methods on this 'container' class!
# pylint: disable=too-few-public-methods
class MakefileRuleCollection:
    """Defines a collection of MakefileRule objects.

    Defines a common set of MakefileRule objects.  Provides functionality to validate those rules
    that exist.

    Attributes:
        clean_rule: Optional; MakefileRule object used to clean the environment.
        build_rule: Optional; MakefileRule object used to build the binary, distribution, etc.
        install_rule: Optional; MakefileRule object used to install the binary, distribution, etc.
        uninstall_rule: Optional; MakefileRule object used to uninstall what was installed.
    """

    # CORE CLASS METHODS
    # Methods listed in suggested call order

    def __init__(self, clean_rule: MakefileRule = None, build_rule: MakefileRule = None,
                 install_rule: MakefileRule = None, uninstall_rule: MakefileRule = None) -> None:
        """MakefileRuleCollection ctor.

        Takes all of the desired MakefileRule objects necessary to clean, build, install, and
        uninstall something utilizing Makefile rules.

        Raises:
            None
        """
        # ATTRIBUTES
        self._validated = False  # Set True by self._validate_input() after input validated
        self.build_rule = build_rule
        self.clean_rule = clean_rule
        self.install_rule = install_rule
        self.uninstall_rule = uninstall_rule

    def verify(self) -> None:
        """Verifies any defined objects.

        Validates all objects provided by the caller.  Verifies data type.  Calls the
        MakefileRule.verify() method for each object that was defined.  Ignores undefined objects.
        Does not require that any objects be defined (but why would you do that?).

        Args:
            None

        Raises:
            TypeError: A non-MakefileRule was provided by the caller.
            Bubbles up any MakefileRule exceptions.
        """
        self._validate_input()
        self._verify_input()

    # CLASS HELPER METHODS
    # Methods listed in alphabetical order
    def _validate_input(self) -> None:
        """Validates user input.

        Validates all of the attributes provided by the user in the constructor.

        Args:
            None

        Raises:
            TypeError: Invalid data type.
        """
        # INPUT VALIDATION
        if self.build_rule is not None:
            validate_type(self.build_rule, 'build_rule', MakefileRule)
        if self.clean_rule is not None:
            validate_type(self.clean_rule, 'clean_rule', MakefileRule)
        if self.install_rule is not None:
            validate_type(self.install_rule, 'install_rule', MakefileRule)
        if self.uninstall_rule is not None:
            validate_type(self.uninstall_rule, 'uninstall_rule', MakefileRule)
        self._validated = True  # If you made it here, the input is good

    def _verify_input(self) -> None:
        """Validates and verifies user input.

        Validates the input if it hasn't been accomplished yet.  MakefileRule.verify() method for
        each object that was defined.  Ignores undefined objects.

        Args:
            None

        Raises:
            Bubbles up any _validate_input() exceptions and MakefileRule exceptions.
        """
        # INPUT VALIDATION
        if not self._validated:
            self._validate_input()
        if self.build_rule:
            self.build_rule.verify()
        if self.clean_rule:
            self.clean_rule.verify()
        if self.install_rule:
            self.install_rule.verify()
        if self.uninstall_rule:
            self.uninstall_rule.verify()
# pylint: enable=too-few-public-methods
