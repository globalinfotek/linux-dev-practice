"""Standard functionality to validate the format and content of parameters.

This module defines how variables are type-validated, and how string and list parameters are
validated.

    Typical usage example:

    from hobo.validation import validate_list, validate_string, validate_type

    validate_list(self._options, 'options', can_be_empty=True)
    validate_string(self._makefile_rule, 'makefile_rule')
    validate_type(self._as_root, 'as_root', bool)
"""
# Standard Imports
from typing import Any
# Third Party Imports
# Local Imports


def validate_list(validate_this: list, param_name: str, can_be_empty: bool = True) -> None:
    """Standardizes how this module validates list parameters.

    Verifies validate_this is a list. Type validation is handled by validate_type().

    Args:
        validate_this: The parameter to validate.
        param_name: The name of the parameter to be used in exception messages.
        can_be_empty: Optional; If False, this function verifies validate_this is not empty.

    Raises:
        TypeError: validate_this is not a list.
        ValueError: validate_this is empty and can_be_empty is False.
    """
    # LOCAL VARIABLES
    bad_val = '"{}" can not be empty'  # Template for empty strings

    # VALIDATION
    validate_type(validate_this, param_name, list)
    if not validate_this and not can_be_empty:
        raise ValueError(bad_val.format(param_name))


def validate_string(validate_this: str, param_name: str, can_be_empty: bool = False) -> None:
    """Standardizes how this module validates string parameters.

    Verifies validate_this is a string. Type validation is handled by validate_type().

    Args:
        validate_this: The parameter to validate.
        param_name: The name of the parameter to be used in exception messages.
        can_be_empty: Optional; If False, this function verifies validate_this is not empty.

    Raises:
        TypeError: validate_this is not a string.
        ValueError: validate_this is empty and can_be_empty is False.
    """
    # LOCAL VARIABLES
    bad_val = '"{}" can not be empty'  # Template for empty strings

    # VALIDATION
    validate_type(validate_this, param_name, str)
    if not validate_this and not can_be_empty:
        raise ValueError(bad_val.format(param_name))


def validate_type(var: Any, var_name: str, var_type: type) -> None:
    """Standardizes how variables are type-validated.

    Verifies var is the same type represented in var_type. This function does not validate input.

    Args:
        var: The variable to type-validate.
        var_name: The name of the variable to be used in exception messages.
        var_type: The expected variable type.

    Raises:
        TypeError: Invalid data type.
    """
    if not isinstance(var, var_type):
        raise TypeError(f'{var_name} expected type {var_type}, instead received type {type(var)}')
